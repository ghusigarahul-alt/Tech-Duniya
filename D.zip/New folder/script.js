// --- Slideshow Functionality ---
let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  
  slides[slideIndex-1].style.display = "block";
}

// Auto advance slides (optional)
setInterval(() => {
    plusSlides(1);
}, 5000); // Change slide every 5 seconds


// --- Add to Cart (Frontend Mock) ---
document.addEventListener('DOMContentLoaded', () => {
    const cartButton = document.querySelector('.cart-icon');
    let cartCount = 0;

    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', (event) => {
            // Get product name for alert
            const productName = event.target.closest('.product-card').querySelector('h3').textContent;
            
            // Update cart count
            cartCount++;
            cartButton.textContent = `🛒 (${cartCount})`;

            alert(`${productName} added to cart! (Frontend Simulation)`);
        });
    });
});